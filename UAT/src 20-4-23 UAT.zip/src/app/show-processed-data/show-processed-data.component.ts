import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-processed-data',
  templateUrl: './show-processed-data.component.html',
  styleUrls: ['./show-processed-data.component.scss']
})
export class ShowProcessedDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
