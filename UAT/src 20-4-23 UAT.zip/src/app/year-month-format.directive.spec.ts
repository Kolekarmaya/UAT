import { YearMonthFormatDirective } from './year-month-format.directive';

describe('YearMonthFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new YearMonthFormatDirective();
    expect(directive).toBeTruthy();
  });
});
