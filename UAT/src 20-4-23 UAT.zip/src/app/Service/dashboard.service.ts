import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { formatDate } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  groups_surrender_fail = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Unpaid Premium recovery not done', text: 'Unpaid Premium recovery not done' },
    { value: 'Policy Deposited amount not added', text: 'Policy Deposited amount not added' },
    { value: 'Incorrect Outstanding loan amount calculated by system', text: 'Incorrect Outstanding loan amount calculated by system' },
    { value: 'Incorrect rate of  interest taken by system', text: 'Incorrect rate of  interest taken by system' },
    { value: 'System Paid only 45 & 50 % amount on premium paid', text: 'System Paid only 45 & 50 % amount on premium paid' },
    { value: 'Amount Lying In Outstanding Disbursements', text: 'Amount Lying In Outstanding Disbursements' },
    { value: 'Incorrect  Calculation', text: 'Incorrect  Calculation' },
    { value: 'Others', text: 'Others' }
  ];

  groups_maturity_fail = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Unpaid Premium recovery not done', text: 'Unpaid Premium recovery not done' },
    { value: 'Policy Deposited amount not added', text: 'Policy Deposited amount not added' },
    { value: 'Only Accumulated premium paying', text: 'Only Accumulated premium paying' },
    { value: 'Funds Lying In Outstanding Disbursements', text: 'Funds Lying In Outstanding Disbursements' },
    { value: 'Incorrect  Calculation', text: 'Incorrect  Calculation' },
    { value:'Maturity amount not payable as per staff Benefit', text: 'Maturity amount not payable as per staff Benefit'},
    { value: 'Others', text: 'Others' }
  ];

  groups_death_claims_fail = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Unpaid Premium recovery not done', text: 'Unpaid Premium recovery not done' },
    { value: 'Policy Deposit amount not added', text: 'Policy Deposit amount not added' },
    { value: 'Incorrect Outstanding loan amount calculated by system', text: 'Incorrect Outstanding loan amount calculated by system' },
    { value: 'Incorrect rate of  interest taken by system', text: 'Incorrect rate of  interest taken by system' },
    { value: 'Incorrect claim decision', text: 'Incorrect claim decision' },
    { value: 'Incorrect Calculation', text: 'Incorrect Calculation' },
    { value: 'Others', text: 'Others' }
  ];

  groups_repudiation_fail = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Incorrect RPU logic', text: 'Incorrect RPU logic' },
    { value: 'Incorrect Outstanding loan amount calculated by system', text: 'Incorrect Outstanding loan amount calculated by system' },
    { value: 'Unpaid Premium recovery not done', text: 'Unpaid Premium recovery not done' },
    { value: 'Incorrect claim decision', text: 'Incorrect claim decision' },
    { value: 'Policy Deposit amount not added', text: 'Policy Deposit amount not added' },
    { value: 'Incorrect Calculation', text: 'Incorrect Calculation' },
    { value: 'Others', text: 'Others' }
  ];

  death_claims = [ 
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Bonus Issue', text: 'Bonus Issue' },
    { value: 'DOR>DOD & Claim Admitted - Recheck reqd', text: 'DOR>DOD & Claim Admitted - Recheck reqd' },
    { value: 'GA - Incorrect Under product 2K', text: 'GA - Incorrect Under product 2K' },
    { value: 'Admin Caharge Recovery - Incorrect', text: 'Admin Caharge Recovery - Incorrect' },
    { value: 'Mortality Caharge Recovery - Incorrect', text: 'Mortality Caharge Recovery - Incorrect' },
    { value: 'Incorrect Fund Value - NAV  other than DOI ', text: 'Incorrect Fund Value - NAV  other than DOI' },
    { value: 'RPU SA/BSA  - Incorrect', text: 'RPU SA/BSA  - Incorrect' },
    { value: 'Rider SA not added in Death Benefit', text: 'Rider SA not added in Death Benefit' },
    { value: 'Liablity(OD) Mismatch', text: 'Liablity(OD) Mismatch' },
    { value: 'Unpaid Premium Recovery not done', text: 'Unpaid Premium Recovery not done' },
    { value: 'Repudiation ND in DGH case - Incorrect Death Benefit [ULIP]', text: 'Repudiation ND in DGH case - Incorrect Death Benefit [ULIP]' },
    { value: '1P - Product System is adding Bonus in Death Benefit', text: '1P - Product System is adding Bonus in Death Benefit' },
    { value: 'PDCL amount Incorrect', text: 'PDCL amount Incorrect' },
    { value: 'Increasing  SA - Incorrect', text: 'Increasing  SA - Incorrect' },
    { value: 'Loan /interest  Recovery not done', text: 'Loan /interest  Recovery not done' },
    { value: 'Others', text: 'Others' },
    // { value: '', text: '' },
  ];

  surrender = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Unitisation (1180) @ Revival', text: 'Unitisation (1180) @ Revival' },
    { value: 'RPU SA/BSA  - Incorrect', text: 'RPU SA/BSA  - Incorrect' },
    { value: 'Liablity(OD) Mismatch', text: 'Liablity(OD) Mismatch' },
    { value: 'Bonus Issue', text: 'Bonus Issue' },
    { value: 'SB Recovery - Incorrect', text: 'SB Recovery - Incorrect' },
    { value: 'GSV Factor - Incorrect', text: 'GSV Factor - Incorrect' },
    { value: 'Incorrect no. Of Loyalty Additions', text: 'Incorrect no. Of Loyalty Additions' },
    { value: 'SSV Factor - Incorrect', text: 'SSV Factor - Incorrect' },
    { value: 'CVB Factor - Incorrect', text: 'CVB Factor - Incorrect' },
    { value: 'Loan /interest  Recovery not done', text: 'Loan /interest  Recovery not done' },
    { value: 'Others', text: 'Others' }
  ];
  survival_benifit = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Bonus Issue - 1P', text: 'Bonus Issue - 1P' },
    { value: 'RPU SA/BSA  - Incorrect', text: 'RPU SA/BSA  - Incorrect' },
    { value: 'Loan /interest  Recovery not done', text: 'Loan /interest  Recovery not done' },
    { value: 'Pusa Factor - Incorrect', text: 'Pusa Factor - Incorrect' },
    { value: 'Liablity(OD) Mismatch', text: 'Liablity(OD) Mismatch' },
    { value: 'Others', text: 'Others' }
  ];
  
  maturity = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value : 'Unitisation (1180) @ Revival', text : 'Unitisation (1180) @ Revival'},
    { value : 'Additional Unitization (IBI, MIG, FMC) - 1M ', text : "Additional Unitization (IBI, MIG, FMC) - 1M "},
    { value: 'Units available in policy after exit', text: 'Units available in policy after exit' },
    { value: 'Bonus Issue', text: 'Bonus Issue' },
    { value: 'Additional CLAWBACK entries', text: 'Additional CLAWBACK entries' },
    { value: 'Units in regular & Disco fund @ exit', text: 'Units in regular & Disco fund @ exit' },
    { value: 'Incorrect Unitisation @ DISCO', text: 'Incorrect Unitisation @ DISCO' },
    { value: 'RPU SA/BSA  - Incorrect', text: 'RPU SA/BSA  - Incorrect' },
    { value: 'Loan /interest  Recovery not done', text: 'Loan /interest  Recovery not done' },
    { value: 'Incorrect no. Of Loyalty Additions', text: 'Incorrect no. Of Loyalty Additions' },
    { value: 'Pusa Factor - Incorrect', text: 'Pusa Factor - Incorrect' },
    { value: 'Increasing  SA - Incorrect', text: 'Increasing  SA - Incorrect' },
    { value: 'Liablity(OD) Mismatch', text: 'Liablity(OD) Mismatch' },
    { value: 'Others', text: 'Others' }
  ];

  ltr = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Unitisation (1180) @ Revival', text: 'Unitisation (1180) @ Revival' },
    { value: 'Incorrect Unitisation @ DISCO', text: 'Incorrect Unitisation @ DISCO' },
    { value: 'LTR in Revival Period', text: 'LTR in Revival Period' },
    { value: 'LTR in Last policy year', text: 'LTR in Last policy year' },
    { value: 'LTR in Premium Holiday', text: 'LTR in Premium Holiday' },
    { value: 'Units in regular & Disco fund @ exit', text: 'Units in regular & Disco fund @ exit' },
    { value: 'Others', text: 'Others' }
  ];
  
  annuity_payout = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Purchase price includes GST', text: 'Purchase price includes GST' },
    { value: 'Others', text: 'Others' }
    // { value: '', text: '' },
  ];

  flc = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Medical fee not deducted', text: 'Medical fee not deducted' },
    { value: 'pro-rata Mortality not deducted', text: 'pro-rata Mortality not deducted' },
    { value: 'Others', text: 'Others' }
  ];

  ulip_approved_death_claims = [
    { value: 'Incorrect death benefit calculation', text: 'Incorrect death benefit calculation' },
    { value: 'Incorrect PPA/Fund value', text: 'Incorrect PPA/Fund value' },
    { value: 'Incorrect Horizon/Platinum cover benefit calculation', text: 'Incorrect Horizon/Platinum cover benefit calculation' },
    { value: 'Incorrect recovery of unpaid/mortality premium', text: 'Incorrect recovery of unpaid/mortality premium' },
    { value: 'Clear Case', text: 'Clear Case' }
  ];
  ulip_repudiated_death_claims = [
    { value: 'Incorrect death benefit calculation', text: 'Incorrect death benefit calculation' },
    { value: 'Clear Case', text: 'Clear Case' }
  ];
  non_ulip_approved_death_claims = [
    { value: 'Incorrect death benefit calculation', text: 'Incorrect death benefit calculation' },
    { value: 'Incorrect Bonus/GA  calculation', text: 'Incorrect Bonus/GA calculation' },
    { value: 'Incorrect PPA calculation', text: 'Incorrect PPA calculation' },
    { value: 'Incorrect ISA logic', text: 'Incorrect ISA logic' },
    { value: 'Incorrect SA', text: 'Incorrect SA' },
    { value: 'Incorrect Rider payout', text: 'Incorrect Rider payout' },
    { value: 'Incorrect recovery of Unpaid/terminal premium', text: 'Incorrect recovery of Unpaid/terminal premium' },
    { value: 'Clear Case', text: 'Clear Case' }
  ];
  non_ulip_repudiated_death_claims = [
    { value: 'Incorrect death benefit calculation', text: 'Incorrect death benefit calculation' },
    { value: 'Incorrect Bonus/GA calculation', text: 'Incorrect Bonus/GA calculation' },
    { value: 'Incorrect PPA calculation', text: 'Incorrect PPA calculation' },
    { value: 'Incorrect ISA logic', text: 'Incorrect ISA logic' },
    { value: 'Incorrect PUSA factor applied', text: 'Incorrect PUSA factor applied' },
    { value: 'Incorrect RPU logic', text: 'Incorrect RPU logic' },
    { value: 'Clear Case', text: 'Clear Case' }
  ];
  annuity_death_claims = [
    { value: 'Incorrect death benefit calculation', text: 'Incorrect death benefit calculation' },
    { value: 'Incorrect Rider payout', text: 'Incorrect Rider payout' },
    { value: 'Clear Case', text: 'Clear Case' }
  ];

  indigo_death_claims = [
    { value: 'Out of scope for checking calculation', text: 'Out of scope for checking calculation' }
  ];
  rt_group_death_claims = [
    { value: 'Out of scope for checking calculation', text: 'Out of scope for checking calculation' }
  ];
//pravin changes comment
  qcRemarksValues = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Unpaid Premium recovery not done', text: 'Unpaid Premium recovery not done' },
    { value: 'Policy Deposited amount not added', text: 'Policy Deposited amount not added' },
    { value: 'Only Accumulated premium paying', text: 'Only Accumulated premium paying' },
    { value: 'Funds Lying In Outstanding Disbursements', text: 'Funds Lying In Outstanding Disbursements' },
    { value: 'Incorrect  Calculation', text: 'Incorrect  Calculation' },
    { value:'Maturity amount not payable as per staff Benefit', text: 'Maturity amount not payable as per staff Benefit'},
    { value: 'Others', text: 'Others' }
  ];

  ulip_non_ulip_maturity = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Incorrect calculation', text: 'Incorrect calculation' },

  ]
  ulip_non_ulip_maturity_lock = [
    { value: 'Clear Case', text: 'Clear Case' },
    { value: 'Incorrect calculation', text: 'Incorrect calculation' },
    { value: 'Out Of Scope Lock-In Future SV Case', text: 'Out Of Scope Lock-In Future SV Case' }

  ]
  currentDate = new Date();
  constructor(private httpClient: HttpClient,
    //private datePipe: DatePipe
  ) {
    //this.currentDate = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd');              
  }



  public updatePolicyData(policyData, moduleId, processId, requested_by, subModuleId) {
    console.log('updatePolicyData :: policyData =>', policyData, moduleId, processId, requested_by, subModuleId);

    console.log('currentDate >>', new Date());
    console.log(formatDate(new Date(), 'dd/MM/yyyy', 'en'));
    var date = new Date();
    var hours: any = date.getHours();
    if (hours < 10) {
      hours = '0' + hours;
    }
    var minutes: any = date.getMinutes();
    if (minutes < 10) {
      minutes = '0' + minutes;
    }
    var seconds: any = date.getMilliseconds();
    if (seconds < 10) {
      seconds = '0' + seconds;
    }
    else if (seconds > 99) {
      seconds = seconds.toString().slice(0, 2);
    }
    // console.log('time>>')

    var timeStamp = hours + ':' + minutes + ':' + seconds;
    var dateStamp = formatDate(date, 'dd/MM/yyyy', 'en')
    console.log('timeStamp ::::', timeStamp);
    console.log('dateStamp ::::', dateStamp);

    let policyDetail = {
      'module_id': moduleId,
      'request_action': processId,
      'requested_by': requested_by,
      'subModuleId': subModuleId,
      'policy_no': policyData['POLICY_NO'],
      'wfthread': policyData['WFTHREAD'],
      'uni_id': policyData['UNI_ID'],
      'pq_qc_flag': policyData['PQ_QC_FLAG'],
      'pq_qc_remarks': policyData['PQ_QC_REMARKS'],
      'QC_Calculated_Value': policyData['QC_Calculated_Value'] ? policyData['QC_Calculated_Value'] : 0.0,
      'qc_date': dateStamp,
      'qc_time': timeStamp
    };

    console.log('policyDetail ::', policyDetail);

   //let url = "../../assets/newData.json";
    //let url = 'http://localhost:6543/core/processOutputFlag';
    //  let url="../../assets/bulk.json"

   let url = '/core/processOutputFlag';
    let httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
    let options = {
      headers: httpHeaders,
      params: policyDetail
    };

    // console.log('policyDetail == ', policyDetail);
   return this.httpClient.post<any>(url, policyDetail, options);
    //  return this.httpClient.get<any>(url);

  }

  public fetchAfterQCPolicyData(moduleId, processId, subModuleId, startDate, endDate) {
    let detail = {
      'module_id': moduleId,
      'request_action': processId,
      'subModuleId': subModuleId,
      'startDate': startDate,
      'endDate': endDate
    };
    console.log('detail ::', detail);

    let url = '/core/fetchAfterQCData';//todo
//  let url = "../../assets/newData_afterQC.json";
    //  let url="../../assets/bulk.json"
        //  let url="../../assets/databulk.json"


    let httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
    let options = {
      headers: httpHeaders,
      params: detail
    };

    return this.httpClient.post<any>(url, detail, options);
    // return this.httpClient.get<any>(url);
  }

  public updateBulkPolicyData(policyData, moduleId, processId, requested_by, subModuleId) {
    console.log('updatePolicyData :: policyData =>', policyData);
    var date = new Date();
    var hours: any = date.getHours();
    if (hours < 10) {
      hours = '0' + hours;
    }
    var minutes: any = date.getMinutes();
    if (minutes < 10) {
      minutes = '0' + minutes;
    }
    var seconds: any = date.getMilliseconds();
    if (seconds < 10) {
      seconds = '0' + seconds;
    }
    else if (seconds > 99) {
      seconds = seconds.toString().slice(0, 2);
    }
    // console.log('time>>')

    var timeStamp = hours + ':' + minutes + ':' + seconds;
    var dateStamp = formatDate(date, 'dd/MM/yyyy', 'en')
    let policyArray = []
    for (let index = 0; index < policyData.length; index++) {
      let policyDetail = {
        'module_id': moduleId,
        'request_action': processId,
        'requested_by': requested_by,
        'subModuleId': subModuleId,
        'policy_no': policyData[index]['POLICY_NO'],
        'wfthread': policyData[index]['WFTHREAD'],
        'uni_id': policyData[index]['UNI_ID'],
        'pq_qc_flag': policyData[index]['PQ_QC_FLAG'],
        'pq_qc_remarks': policyData[index]['PQ_QC_REMARKS'],
        'QC_Calculated_Value': policyData[index]['QC_Calculated_Value'] ? policyData[index]['QC_Calculated_Value'] : 0.0,
        'qc_date': dateStamp,
        'qc_time': timeStamp
      };
      policyArray.push(policyDetail)

    }
    console.log(policyArray);

    // let url = "../../assets/newData.json";
    // let url = 'http://localhost:6543/core/processOutputFlag';
    //  let url="../../assets/bulk.json"
    let url = '/core/processOutputFlag'; //TODO
    let httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
    let options = {
      headers: httpHeaders,
      params: policyArray[0]
    };
  //rohit changes 14-10-22


  return this.httpClient.post<any>(url, policyArray, options);
    // return this.httpClient.get<any>(url);//TODO

  }

}
