import { DateFormatDirective } from './date-format.directive';

describe('DateFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new DateFormatDirective();
    expect(directive).toBeTruthy();
  });
});
